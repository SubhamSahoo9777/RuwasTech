import { StyleSheet, Text, View } from "react-native";
import React from "react";

const tabDashBoard = () => {
  return (
    <View>
      <Text>tabDashBoard</Text>
    </View>
  );
};

export default tabDashBoard;

const styles = StyleSheet.create({});
