import * as SQLite from 'expo-sqlite';
const LocalDb = SQLite.openDatabase('testing1');
export default LocalDb;