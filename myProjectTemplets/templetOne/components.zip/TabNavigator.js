import { StyleSheet, Text, View } from "react-native";
import React from "react";

const TabNavigator = () => {
  return (
    <View>
      <Text>TabNavigator</Text>
    </View>
  );
};

export default TabNavigator;

const styles = StyleSheet.create({});
