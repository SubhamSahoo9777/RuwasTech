import {combineReducers} from 'redux'
import UserReducer from './UserReducer'




const CombineAllReducer=combineReducers({
    UserReducer,
  
})
export default CombineAllReducer
