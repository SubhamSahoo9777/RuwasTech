export const DarkScheme = {
  primary: "rgb(220, 184, 255)",
  sbc: "white",
  button: {
    drawerButton: "green",
    drawerText: "black",
  },
  dropDown: {},
  dateTimePicker: {},
  textInput: {},
  screenHeader: {},
  screen: {
    login: "#4a5ac7",
  },
  icon: {},
  statusbar: {
    global: "#4a5ac7",
  },
};
