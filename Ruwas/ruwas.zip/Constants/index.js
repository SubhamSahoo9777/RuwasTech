const length = 5;
const year = new Date().getFullYear() - length;
export default LocalData = {
    Finalcial_Year: [...Array(length).keys()].map(v => `${year + v}/${year + v + 1}`),
    year_Of_Construction: [...Array(length).keys()].map(v => `${year + v}`),
    districtsName: [
        { district: "Abim", rwsrcId: 10 },
        { district: "Adjumani", rwsrcId: 9 },
        { district: "Agago", rwsrcId: 9 },
        { district: "Alebtong", rwsrcId: 9 },
        { district: "Amolatar", rwsrcId: 9 },
        { district: "Amudat", rwsrcId: 10 },
        { district: "Amuria", rwsrcId: 10 },
        { district: "Amuru", rwsrcId: 9 },
        { district: "Apac", rwsrcId: 9 },
        { district: "Arua", rwsrcId: 9 },
        { district: "Budaka", rwsrcId: 11 },
        { district: "Bududa", rwsrcId: 11 },
        { district: "Bugiri", rwsrcId: 11 },
    
    ],
    
    tableData: [
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },
        {
            No: '1.1',
            "Modal Activity": 'District Water Supply and Sanitation Coordination Committee meetings',
            "Approved Annual Workplan Target": '4',
            "Target Quarter": '1',
            "Performance in Quarter Achieved": '',
            "Cumulative to Date Achieved": '0',
            "Percentage Workplan": '0',
            'Expenditure (Quarter) (Ugx)': '',
            'Cumulative Expenditure(Ugx)': '0',
            'Annual Budget(Ugx)': '54,00,000',
            Comments: ''
        },

    ]
}