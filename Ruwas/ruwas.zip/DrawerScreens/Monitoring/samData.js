export   const Data = [{
    New_Id: '19739FDRE', Parish: 'ADEFFD', Village: 'GEREFC', Type: 'EVACD', YoC: '3222', Source_Name: 'DFEGE', Source_Number: 'EGH4EFC',
    Functionality: { F: "Yes", Fniu: "Derf", NF: "NO", D: "DEFC" },
    Source_Funder: 'DGGEECDFDF',
    WSC_Functional: { Yes: "TRUE", No: "FALSE" },
    Management: { Fees: "23232", Rep: "FDCD", Meet: "EG4TRF", Env: "CBRRED" },
    Women_In_Key_Position: { Yes: "TRUE", No: "FALSE" },
    Contaminated: { Yes: "FALSE", No: "TRUE" },
    Source_Owner: 'KEOEICNC',
    On_Premise: { Yes: "False", No: "True", HH: "degeacd" },
    Households_Using_the_source: 'DEKIDLDOFC'
  },
  {
    New_Id: '2938EDDKAE', Parish: 'ADEFFD', Village: 'GEREFC', Type: 'EVACD', YoC: '3222', Source_Name: 'DFEGE', Source_Number: 'EGH4EFC',
    Functionality: { F: "Yes", Fniu: "Derf", NF: "NO", D: "DEFC" },
    Source_Funder: 'DGGEECDFDF',
    WSC_Functional: { Yes: "TRUE", No: "FALSE" },
    Management: { Fees: "23232", Rep: "FDCD", Meet: "EG4TRF", Env: "CBRRED" },
    Women_In_Key_Position: { Yes: "TRUE", No: "FALSE" },
    Contaminated: { Yes: "FALSE", No: "TRUE" },
    Source_Owner: 'KEOEICNC',
    On_Premise: { Yes: "False", No: "True", HH: "degeacd" },
    Households_Using_the_source: 'DEKIDLDOFC'
  },
  {
    New_Id: '59OE8EDDKAE', Parish: 'ADEFFD', Village: 'GEREFC', Type: 'EVACD', YoC: '3222', Source_Name: 'DFEGE', Source_Number: 'EGH4EFC',
    Functionality: { F: "Yes", Fniu: "Derf", NF: "NO", D: "DEFC" },
    Source_Funder: 'DGGEECDFDF',
    WSC_Functional: { Yes: "TRUE", No: "FALSE" },
    Management: { Fees: "23232", Rep: "FDCD", Meet: "EG4TRF", Env: "CBRRED" },
    Women_In_Key_Position: { Yes: "TRUE", No: "FALSE" },
    Contaminated: { Yes: "FALSE", No: "TRUE" },
    Source_Owner: 'KEOEICNC',
    On_Premise: { Yes: "False", No: "True", HH: "degeacd" },
    Households_Using_the_source: 'DEKIDLDOFC'
  },
  {
    New_Id: 'POE938EOEKAE', Parish: 'ADEFFD', Village: 'GEREFC', Type: 'EVACD', YoC: '3222', Source_Name: 'DFEGE', Source_Number: 'EGH4EFC',
    Functionality: { F: "Yes", Fniu: "Derf", NF: "NO", D: "DEFC" },
    Source_Funder: 'DGGEECDFDF',
    WSC_Functional: { Yes: "TRUE", No: "FALSE" },
    Management: { Fees: "23232", Rep: "FDCD", Meet: "EG4TRF", Env: "CBRRED" },
    Women_In_Key_Position: { Yes: "TRUE", No: "FALSE" },
    Contaminated: { Yes: "FALSE", No: "TRUE" },
    Source_Owner: 'KEOEICNC',
    On_Premise: { Yes: "False", No: "True", HH: "degeacd" },
    Households_Using_the_source: 'DEKIDLDOFC'
  },
  {
    New_Id: 'K93838EDDKAE', Parish: 'ADEFFD', Village: 'GEREFC', Type: 'EVACD', YoC: '3222', Source_Name: 'DFEGE', Source_Number: 'EGH4EFC',
    Functionality: { F: "Yes", Fniu: "Derf", NF: "NO", D: "DEFC" },
    Source_Funder: 'DGGEECDFDF',
    WSC_Functional: { Yes: "TRUE", No: "FALSE" },
    Management: { Fees: "23232", Rep: "FDCD", Meet: "EG4TRF", Env: "CBRRED" },
    Women_In_Key_Position: { Yes: "TRUE", No: "FALSE" },
    Contaminated: { Yes: "FALSE", No: "TRUE" },
    Source_Owner: 'KEOEICNC',
    On_Premise: { Yes: "False", No: "True", HH: "degeacd" },
    Households_Using_the_source: 'DEKIDLDOFC'
  },
  {
    New_Id: 'RI38EDDKAE', Parish: 'ADEFFD', Village: 'GEREFC', Type: 'EVACD', YoC: '3222', Source_Name: 'DFEGE', Source_Number: 'EGH4EFC',
    Functionality: { F: "Yes", Fniu: "Derf", NF: "NO", D: "DEFC" },
    Source_Funder: 'DGGEECDFDF',
    WSC_Functional: { Yes: "TRUE", No: "FALSE" },
    Management: { Fees: "23232", Rep: "FDCD", Meet: "EG4TRF", Env: "CBRRED" },
    Women_In_Key_Position: { Yes: "TRUE", No: "FALSE" },
    Contaminated: { Yes: "FALSE", No: "TRUE" },
    Source_Owner: 'KEOEICNC',
    On_Premise: { Yes: "False", No: "True", HH: "degeacd" },
    Households_Using_the_source: 'DEKIDLDOFC'
  }
]